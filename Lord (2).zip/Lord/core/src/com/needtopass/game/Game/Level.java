package com.needtopass.game.Game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.needtopass.game.Game.Objects.AbstractGameObject;
import com.needtopass.game.Game.Objects.GameHero;
import com.needtopass.game.Game.Objects.Clouds;
import com.needtopass.game.Game.Objects.Goal;
import com.needtopass.game.Game.Objects.GoldCoin;
import com.needtopass.game.Game.Objects.Mountains;
import com.needtopass.game.Game.Objects.Rocks;
import com.needtopass.game.Game.Objects.WaterOverlay;


public class Level {

    public static final String TAG = Level.class.getName();

    public enum BLOCK_TYPE {
        EMPTY(0, 0, 0), // black
        GOAL(255, 0, 0), // red
        ROCK(0, 255, 0), // green
        PLAYER_SPAWNPOINT(255, 255, 255), // white
        ITEM_GOLD_COIN(255, 255, 0); // yellow

        private int color;

        private BLOCK_TYPE (int r, int g, int b) {
            color = r << 24 | g << 16 | b << 8 | 0xff;
        }

        public boolean sameColor (int color) {
            return this.color == color;
        }

        public int getColor () {
            return color;
        }
    }

    // player character
    public GameHero gameHero;

    // objects
    public Array<Rocks> rocks;
    public Array<GoldCoin> goldcoins;

    // decoration
    public Clouds clouds;
    public Mountains mountains;
    public WaterOverlay waterOverlay;
    public Goal goal;

    public Level (String filename) {
        init(filename);
    }

    private void init (String filename) {
        // player character
        gameHero = null;

        // objects
        rocks = new Array<Rocks>();
        goldcoins = new Array<GoldCoin>();


        // load image file that represents the level data
        Pixmap pixmap = new Pixmap(Gdx.files.internal(filename));
        // scan pixels from top-left to bottom-right
        int lastPixel = -1;
        for (int pixelY = 0; pixelY < pixmap.getHeight(); pixelY++) {
            for (int pixelX = 0; pixelX < pixmap.getWidth(); pixelX++) {
                AbstractGameObject obj = null;
                float offsetHeight = 0;
                // height grows from bottom to top
                float baseHeight = pixmap.getHeight() - pixelY;
                // get color of current pixel as 32-bit RGBA value
                int currentPixel = pixmap.getPixel(pixelX, pixelY);
                // find matching color value to identify block type at (x,y)
                // point and create the corresponding game object if there is match.

                // empty space
                if (BLOCK_TYPE.EMPTY.sameColor(currentPixel)) {
                    // do nothing
                }
                // rock
                else if (BLOCK_TYPE.ROCK.sameColor(currentPixel)) {
                    if (lastPixel != currentPixel) {
                        obj = new Rocks();
                        float heightIncreaseFactor = 0.25f;
                        offsetHeight = -2.5f;
                        obj.position.set(pixelX, baseHeight * obj.dimension.y * heightIncreaseFactor + offsetHeight);
                        rocks.add((Rocks) obj);
                    } else {
                        rocks.get(rocks.size - 1).increaseLength(1);
                    }
                }
                // player spawn point
                else if (BLOCK_TYPE.PLAYER_SPAWNPOINT.sameColor(currentPixel)) {
                    obj = new GameHero();
                    offsetHeight = -3.0f;
                    obj.position.set(pixelX, baseHeight * obj.dimension.y + offsetHeight);
                    gameHero = (GameHero)obj;
                }
                // gold coin
                else if (BLOCK_TYPE.ITEM_GOLD_COIN.sameColor(currentPixel)) {
                    obj = new GoldCoin();
                    offsetHeight = -1.5f;
                    obj.position.set(pixelX, baseHeight * obj.dimension.y + offsetHeight);
                    goldcoins.add((GoldCoin)obj);
                }
                // goal
                else if (BLOCK_TYPE.GOAL.sameColor(currentPixel)) {
                    obj = new Goal();
                    offsetHeight = -7.0f;
                    obj.position.set(pixelX, baseHeight + offsetHeight);
                    goal = (Goal)obj;
                }
                // unknown object/pixel color
                else {
                    // red color channel
                    int r = 0xff & (currentPixel >>> 24);
                    // green color channel
                    int g = 0xff & (currentPixel >>> 16);
                    // blue color channel
                    int b = 0xff & (currentPixel >>> 8);
                    // alpha channel
                    int a = 0xff & currentPixel;
                    Gdx.app.error(TAG, "Unknown object at x<" + pixelX + "> y<" + pixelY + ">: r<" + r + "> g<" + g + "> b<" + b
                            + "> a<" + a + ">");
                }
                lastPixel = currentPixel;
            }
        }

        // decoration
        clouds = new Clouds(pixmap.getWidth());
        clouds.position.set(0, 2);
        mountains = new Mountains(pixmap.getWidth());
        mountains.position.set(-1, -1);
        waterOverlay = new WaterOverlay(pixmap.getWidth());
        waterOverlay.position.set(0, -3.75f);

        // free memory
        pixmap.dispose();
        Gdx.app.debug(TAG, "level '" + filename + "' loaded");
    }

    public void update (float deltaTime) {
        // Hero
        gameHero.update(deltaTime);
        // Rocks
        for (Rocks rock : rocks)
            rock.update(deltaTime);
        // Gold Coins
        for (GoldCoin goldCoin : goldcoins)
            goldCoin.update(deltaTime);
        // Clouds
        clouds.update(deltaTime);
    }

    public void render (SpriteBatch batch) {
        // Draw Mountains
        mountains.render(batch);
        // Draw Goal
        goal.render(batch);
        // Draw Rocks
        for (Rocks rock : rocks)
            rock.render(batch);
        // Draw Gold Coins
        for (GoldCoin goldCoin : goldcoins)
            goldCoin.render(batch);
        // Draw Player Character
        gameHero.render(batch);
        // Draw Water Overlay
        waterOverlay.render(batch);
        // Draw Clouds
        clouds.render(batch);
    }

}
