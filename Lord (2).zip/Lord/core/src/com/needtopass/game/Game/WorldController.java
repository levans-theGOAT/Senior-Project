package com.needtopass.game.Game;

import com.badlogic.gdx.Application.ApplicationType;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Input.Peripheral;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Disposable;
import com.needtopass.game.Game.Objects.GameHero;
import com.needtopass.game.Game.Objects.GoldCoin;
import com.needtopass.game.Game.Objects.Rocks;
import com.needtopass.game.Screens.Transitions.DirectedGame;
import com.needtopass.game.Screens.Transitions.MenuScreen;
import com.needtopass.game.Screens.Transitions.ScreenTransition;
import com.needtopass.game.Screens.Transitions.ScreenTransitionSlide;
import com.needtopass.game.Utility.AudioManager;
import com.needtopass.game.Utility.CameraHelper;
import com.needtopass.game.Utility.Constants;

public class WorldController extends InputAdapter implements Disposable {

    private static final String TAG = WorldController.class.getName();

    private DirectedGame game;
    public Level level;
    public int lives;
    public float livesVisual;
    public int score;
    public float scoreVisual;
    private boolean goalReached;
    private boolean accelerometerAvailable;

    public CameraHelper cameraHelper;

    // Rectangles for collision detection
    private Rectangle r1 = new Rectangle();
    private Rectangle r2 = new Rectangle();

    private float timeLeftGameOverDelay;

    public World b2world;

    public WorldController (DirectedGame game) {
        this.game = game;
        init();
    }

    private void init () {
        accelerometerAvailable = Gdx.input.isPeripheralAvailable(Peripheral.Accelerometer);
        cameraHelper = new CameraHelper();
        lives = Constants.LIVES_START;
        livesVisual = lives;
        timeLeftGameOverDelay = 0;
        initLevel();
    }

    private void initLevel () {
        score = 0;
        scoreVisual = score;
        goalReached = false;
        level = new Level(Constants.LEVEL_01);
        cameraHelper.setTarget(level.gameHero);
        initPhysics();
    }

    private void initPhysics () {
        if (b2world != null) b2world.dispose();
        b2world = new World(new Vector2(0, -9.81f), true);
        // Rocks
        Vector2 origin = new Vector2();
        for (Rocks rock : level.rocks) {
            BodyDef bodyDef = new BodyDef();
            bodyDef.type = BodyType.KinematicBody;
            bodyDef.position.set(rock.position);
            Body body = b2world.createBody(bodyDef);
            rock.body = body;
            PolygonShape polygonShape = new PolygonShape();
            origin.x = rock.bounds.width / 2.0f;
            origin.y = rock.bounds.height / 2.0f;
            polygonShape.setAsBox(rock.bounds.width / 2.0f, rock.bounds.height / 2.0f, origin, 0);
            FixtureDef fixtureDef = new FixtureDef();
            fixtureDef.shape = polygonShape;
            body.createFixture(fixtureDef);
            polygonShape.dispose();
        }
    }

    public void update (float deltaTime) {
        handleDebugInput(deltaTime);
        if (isGameOver() || goalReached) {
            timeLeftGameOverDelay -= deltaTime;
            if (timeLeftGameOverDelay < 0) backToMenu();
        } else {
            handleInputGame(deltaTime);
        }
        level.update(deltaTime);
        testCollisions();
        b2world.step(deltaTime, 8, 3);
        cameraHelper.update(deltaTime);
        if (!isGameOver() && isPlayerInWater()) {
            AudioManager.instance.play(Assets.instance.sounds.liveLost);
            lives--;
            if (isGameOver())
                timeLeftGameOverDelay = Constants.TIME_DELAY_GAME_OVER;
            else
                initLevel();
        }
        level.mountains.updateScrollPosition(cameraHelper.getPosition());
        if (livesVisual > lives) livesVisual = Math.max(lives, livesVisual - 1 * deltaTime);
        if (scoreVisual < score) scoreVisual = Math.min(score, scoreVisual + 250 * deltaTime);
    }

    public boolean isGameOver () {
        return lives < 0;
    }

    public boolean isPlayerInWater () {
        return level.gameHero.position.y < -5;
    }

    private void testCollisions () {
        r1.set(level.gameHero.position.x, level.gameHero.position.y, level.gameHero.bounds.width, level.gameHero.bounds.height);

        // Test collision: Hero Head <-> Rocks
        for (Rocks rock : level.rocks) {
            r2.set(rock.position.x, rock.position.y, rock.bounds.width, rock.bounds.height);
            if (!r1.overlaps(r2)) continue;
            onCollisionHeroHeadWithRock(rock);

        }

        // Test collision:  Hero Head <-> Gold Coins
        for (GoldCoin goldcoin : level.goldcoins) {
            if (goldcoin.collected) continue;
            r2.set(goldcoin.position.x, goldcoin.position.y, goldcoin.bounds.width, goldcoin.bounds.height);
            if (!r1.overlaps(r2)) continue;
            onCollisionHeroWithGoldCoin(goldcoin);
            break;
        }

        // Test collision: Hero Head <-> Goal
        if (!goalReached) {
            r2.set(level.goal.bounds);
            r2.x += level.goal.position.x;
            r2.y += level.goal.position.y;
            if (r1.overlaps(r2)) onCollisionHeroWithGoal();
        }
    }

    private void onCollisionHeroHeadWithRock(Rocks rock) {
        GameHero gameHero = level.gameHero;
        float heightDifference = Math.abs(gameHero.position.y - (rock.position.y + rock.bounds.height));
        if (heightDifference > 0.25f) {
            boolean hitRightEdge  = gameHero.position.x > (rock.position.x + rock.bounds.width / 2.0f);
            if (hitRightEdge ) {
                gameHero.position.x = rock.position.x + rock.bounds.width;
            } else {
                gameHero.position.x = rock.position.x - gameHero.bounds.width;
            }
            return;
        }

        switch (gameHero.jumpState) {
            case GROUNDED:
                break;
            case FALLING:
            case JUMP_FALLING:
                gameHero.position.y = rock.position.y + gameHero.bounds.height + gameHero.origin.y;
                gameHero.jumpState = GameHero.JUMP_STATE.GROUNDED;
                break;
            case JUMP_RISING:
                gameHero.position.y = rock.position.y + gameHero.bounds.height + gameHero.origin.y;
                break;
        }
    }

    private void onCollisionHeroWithGoldCoin(GoldCoin goldcoin) {
        goldcoin.collected = true;
        AudioManager.instance.play(Assets.instance.sounds.pickupCoin);
        score += goldcoin.getScore();
        Gdx.app.log(TAG, "Gold coin collected");
    }

    private void onCollisionHeroWithGoal() {
        goalReached = true;
        timeLeftGameOverDelay = Constants.TIME_DELAY_GAME_FINISHED;
        Vector2 centerPosBunnyHead = new Vector2(level.gameHero.position);
        centerPosBunnyHead.x += level.gameHero.bounds.width;

    }

    private void handleDebugInput (float deltaTime) {
        if (Gdx.app.getType() != ApplicationType.Desktop) return;

        if (!cameraHelper.hasTarget(level.gameHero)) {
            // Camera Controls (move)
            float camMoveSpeed = 5 * deltaTime;
            float camMoveSpeedAccelerationFactor = 5;
            if (Gdx.input.isKeyPressed(Keys.SHIFT_LEFT)) camMoveSpeed *= camMoveSpeedAccelerationFactor;
            if (Gdx.input.isKeyPressed(Keys.LEFT)) moveCamera(-camMoveSpeed, 0);
            if (Gdx.input.isKeyPressed(Keys.RIGHT)) moveCamera(camMoveSpeed, 0);
            if (Gdx.input.isKeyPressed(Keys.UP)) moveCamera(0, camMoveSpeed);
            if (Gdx.input.isKeyPressed(Keys.DOWN)) moveCamera(0, -camMoveSpeed);
            if (Gdx.input.isKeyPressed(Keys.BACKSPACE)) cameraHelper.setPosition(0, 0);
        }

        // Camera Controls (zoom)
        float camZoomSpeed = 1 * deltaTime;
        float camZoomSpeedAccelerationFactor = 5;
        if (Gdx.input.isKeyPressed(Keys.SHIFT_LEFT)) camZoomSpeed *= camZoomSpeedAccelerationFactor;
        if (Gdx.input.isKeyPressed(Keys.COMMA)) cameraHelper.addZoom(camZoomSpeed);
        if (Gdx.input.isKeyPressed(Keys.PERIOD)) cameraHelper.addZoom(-camZoomSpeed);
        if (Gdx.input.isKeyPressed(Keys.SLASH)) cameraHelper.setZoom(1);
    }

    private void handleInputGame (float deltaTime) {
        if (cameraHelper.hasTarget(level.gameHero)) {
            // Player Movement
            if (Gdx.input.isKeyPressed(Keys.LEFT)) {
                level.gameHero.velocity.x = -level.gameHero.terminalVelocity.x;
            } else if (Gdx.input.isKeyPressed(Keys.RIGHT)) {
                level.gameHero.velocity.x = level.gameHero.terminalVelocity.x;
            } else {
                // Use accelerometer for movement if available
                if (accelerometerAvailable) {
                    // normalize accelerometer values from [-10, 10] to [-1, 1]
                    // which translate to rotations of [-90, 90] degrees
                    float amount = Gdx.input.getAccelerometerY() / 10.0f;
                    amount *= 90.0f;
                    // is angle of rotation inside dead zone?
                    if (Math.abs(amount) < Constants.ACCEL_ANGLE_DEAD_ZONE) {
                        amount = 0;
                    } else {
                        // use the defined max angle of rotation instead of
                        // the full 90 degrees for maximum velocity
                        amount /= Constants.ACCEL_MAX_ANGLE_MAX_MOVEMENT;
                    }
                    level.gameHero.velocity.x = level.gameHero.terminalVelocity.x * amount;
                }
                // Execute auto-forward movement on non-desktop platform
                else if (Gdx.app.getType() != ApplicationType.Desktop) {
                    level.gameHero.velocity.x = level.gameHero.terminalVelocity.x;
                }
            }

            // hero Jump
            if (Gdx.input.isTouched() || Gdx.input.isKeyPressed(Keys.SPACE))
                level.gameHero.setJumping(true);
            else
                level.gameHero.setJumping(false);
        }
    }

    private void moveCamera (float x, float y) {
        x += cameraHelper.getPosition().x;
        y += cameraHelper.getPosition().y;
        cameraHelper.setPosition(x, y);
    }

    @Override
    public boolean keyUp (int keycode) {
        // Reset game world
        if (keycode == Keys.R) {
            init();
            Gdx.app.debug(TAG, "Game world resetted");
        }
        // Toggle camera follow
        else if (keycode == Keys.ENTER) {
            cameraHelper.setTarget(cameraHelper.hasTarget() ? null : level.gameHero);
            Gdx.app.debug(TAG, "Camera follow enabled: " + cameraHelper.hasTarget());
        }
        // Back to Menu
        else if (keycode == Keys.ESCAPE || keycode == Keys.BACK) {
            backToMenu();
        }
        return false;
    }

    private void backToMenu () {
        // switch to menu screen
        ScreenTransition transition = ScreenTransitionSlide.init(0.75f, ScreenTransitionSlide.DOWN, false, Interpolation.bounceOut);
        game.setScreen(new MenuScreen(game), transition);
    }

    @Override
    public void dispose () {
        if (b2world != null) b2world.dispose();
    }

}
