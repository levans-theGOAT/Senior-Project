package com.needtopass.game.Screens.Transitions;

public class LeaderBoard {


}
