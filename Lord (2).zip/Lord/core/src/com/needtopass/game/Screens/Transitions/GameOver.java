package com.needtopass.game.Screens.Transitions;

import com.badlogic.gdx.InputProcessor;

public class GameOver extends  AbstractGameScreen {
    public GameOver(DirectedGame game) {
        super(game);
    }

    @Override
    public void render(float deltaTime) {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void show() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void pause() {

    }

    @Override
    public InputProcessor getInputProcessor() {
        return null;
    }
}
