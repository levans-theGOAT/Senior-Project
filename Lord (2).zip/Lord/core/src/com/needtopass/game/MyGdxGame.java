package com.needtopass.game;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.math.Interpolation;
import com.needtopass.game.Game.Assets;
import com.needtopass.game.Screens.Transitions.DirectedGame;
import com.needtopass.game.Screens.Transitions.MenuScreen;
import com.needtopass.game.Screens.Transitions.ScreenTransition;
import com.needtopass.game.Screens.Transitions.ScreenTransitionSlice;
import com.needtopass.game.Utility.AudioManager;
import com.needtopass.game.Utility.GamePreferences;


public class MyGdxGame extends DirectedGame {

	@Override
	public void create () {
		// Set Libgdx log level
		Gdx.app.setLogLevel(Application.LOG_DEBUG);

		// Load assets
		Assets.instance.init(new AssetManager());

		// Load preferences for audio settings and start playing music
		GamePreferences.instance.load();
		AudioManager.instance.play(Assets.instance.music.song01);

		// Start game at menu screen
		ScreenTransition transition = ScreenTransitionSlice.init(2, ScreenTransitionSlice.UP_DOWN, 10, Interpolation.pow5Out);
		setScreen(new MenuScreen(this), transition);
	}

}
