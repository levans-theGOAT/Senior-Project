package com.needtopass.game.Utility;

import javax.xml.transform.Result;

public abstract class DataBase {

    //Creates Database
    protected static String database_name = "high_score.db";
    protected static DataBase instance = null;
    protected static int version = 1;
//run an sql query similar to create
    public abstract void execute(String sql);
    //returns the number of rows affected
    public abstract int executeUpdate(String sql);
    //Runs a query and returns an Object with all the results of the query.
    public abstract Result query(String sql);

    public void onCreate(){
        execute("CREATE TABLE 'high_score' ('_id' INTEGER PRIMARY KEY  NOT NULL , 'name' CHAR NOT NULL , 'score' INTEGER NOT NULL, 'time' INTEGER NOT NULL, );");
        execute("INSERT INTO 'high_score'(name,score,time)");

        Result q=query("SELECT TOP 10 * FROM 'high_score'");
        if (!q.isEmpty()){
            q.moveToNext();
            System.out.println("high_score of "+q.getString(q.getColumnIndex("name"))+": "+q.getString(q.getColumnIndex("score"))+": "+q.getString(q.getColumnIndex("time")));
        }
    }
    public void onUpgrade(){
        execute("DROP TABLE IF EXISTS 'high_score';");
        onCreate();
        System.out.println("DB updated!");
    }
    //Interface to be implemented on both Android and Desktop Applications
    public interface Result{
        public boolean isEmpty();
        public boolean moveToNext();
        public int getColumnIndex(String name);
        public float getFloat(int columnIndex);
        public String getString(int name);
    }
}
