package com.needtopass.game.Utility;


import javax.naming.Context;

public class DatabaseAndroid extends DataBase {
    protected SQLiteOpenHelper db_connection;
    protected SQLiteDatabase stmt;

    public DatabaseAndroid(Context context) {
        db_connection = new AndroidDB(context, database_name, null, version);
        stmt=db_connection.getWritableDatabase();
    }


    @Override
    public void execute(String sql) {

    }

    @Override
    public int executeUpdate(String sql) {
        return 0;
    }

    @Override
    public Result query(String sql) {
        return null;
    }
}
